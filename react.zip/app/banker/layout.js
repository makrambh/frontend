import BankerLayout from "@/components/banker-layout"

export default function Layout({ children }) {
  return <BankerLayout>{children}</BankerLayout>
}
